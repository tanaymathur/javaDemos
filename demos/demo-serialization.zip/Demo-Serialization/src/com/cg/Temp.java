package com.cg;

public class Temp {
	public Temp() {
		System.out.println("inside Temp()...");
	}
}
